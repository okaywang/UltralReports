﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MySocket;

namespace DTUSendTest
{
    public partial class Send_Form : Form
    {
        #region 变量声明
        private SmsBaseClass fSmsBaseClass;
        #endregion

        #region 构造函数
        public Send_Form()
        {
            InitializeComponent();
            
        }
        #endregion

        #region 退出
        private void ExitBtn_Click(object sender, EventArgs e)
        {            
            Close();
        }
        #endregion

        #region 发送
        private void OKBtn_Click(object sender, EventArgs e)
        {
            fSmsBaseClass.SendDTU(PhoneTextBox.Text, 0, ContentTextBox.Text.ToString());            
        }
        #endregion

        #region Load事件
        private void Send_Form_Load(object sender, EventArgs e)
        {
            fSmsBaseClass = new SmsBaseClass();
            fSmsBaseClass.m_Textbox = this.textBox1;
        }
        #endregion

        #region 打开端口
        private void OpenBtn_Click(object sender, EventArgs e)
        {
            fSmsBaseClass.OpenPort("COM1");
        }
        #endregion

        #region 关闭端口
        private void CloseBtn_Click(object sender, EventArgs e)
        {
            fSmsBaseClass.ClosePort();
        }
        #endregion
    }
}